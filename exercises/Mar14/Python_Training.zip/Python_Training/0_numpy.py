# -*- coding: utf-8 -*-
"""
Created on Mon Mar 13 13:44:49 2017

@author: tih
"""

import numpy as np

# Create a 4x6 array with only zeros
A = np.zeros([4,6])

# Print array A
print(A)

# Create a 3x9 array with only ones
B = np.ones([3,9])

# Print array B
print(B)

# Create a 4x8 array with random values
C = np.random.rand(4,8)

# Print array C
print(C)


